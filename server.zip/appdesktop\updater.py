import os
import sys
import time
import urllib.request
import urllib.error
import subprocess

SERVER_URL = os.getenv("MUSICCLOUD_SERVER", "http://199.83.103.63:8900")
LOCAL_DIR = os.path.dirname(os.path.abspath(__file__))
PLAYER_FILE = os.path.join(LOCAL_DIR, "desktop_player.py")
LOCAL_UPDATES_TXT = os.path.join(LOCAL_DIR, "updates.txt")

def read_remote_updates_txt() -> dict:
    url = f"{SERVER_URL}/api/desktop/updates.txt"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "MusicCloudUpdater/1.0"})
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            if resp.status == 200:
                content = resp.read().decode("utf-8")
                lines = [line.strip() for line in content.splitlines() if line.strip()]
                data = {}
                for line in lines:
                    if ":" in line:
                        k, v = line.split(":", 1)
                        data[k.strip().lower()] = v.strip()
                return data
    except Exception as e:
        print(f"[!] Server offline or unreachable ({e}).")
    return {}

def download_file(filename: str):
    file_url = f"{SERVER_URL}/api/desktop/files/{filename}"
    target_path = os.path.join(LOCAL_DIR, filename)
    temp_path = target_path + ".tmp"
    
    print(f"[*] Downloading updated file: {filename} ...")
    try:
        req = urllib.request.Request(file_url, headers={"User-Agent": "MusicCloudUpdater/1.0"})
        with urllib.request.urlopen(req, timeout=10.0) as resp:
            if resp.status == 200:
                with open(temp_path, "wb") as f:
                    f.write(resp.read())
                if os.path.exists(target_path):
                    try:
                        os.remove(target_path)
                    except Exception:
                        pass
                os.rename(temp_path, target_path)
                print(f"[OK] {filename} updated successfully!")
    except Exception as e:
        print(f"[!] Error downloading {filename}: {e}")

def main():
    print("==================================================")
    print("       MusicCloud Desktop Smart Updater")
    print("==================================================")
    print(f"[*] Checking updates from server: {SERVER_URL} ...")
    
    remote_data = read_remote_updates_txt()
    is_updated = remote_data.get("updated", "").lower()
    
    if is_updated == "yes":
        print("[+] updates.txt says: updated: yes")
        print(f"[*] New version: {remote_data.get('version', 'latest')}")
        print(f"[*] Changelog: {remote_data.get('changelog', '-')}")
        
        # Получаем список файлов для обновления
        files_str = remote_data.get("files", "desktop_player.py")
        file_list = [f.strip() for f in files_str.split(",") if f.strip()]
        
        for fname in file_list:
            if fname != "updater.py":  # updater обновляет остальные файлы
                download_file(fname)
        
        # Сохраняем локально updates.txt
        try:
            with open(LOCAL_UPDATES_TXT, "w", encoding="utf-8") as f:
                f.write(f"updated: yes\nversion: {remote_data.get('version', '1.0.0')}\n")
        except Exception:
            pass
        print("[SUCCESS] All files updated successfully!")
    else:
        print(f"[-] updates.txt status: '{is_updated or 'no'}' -> Skipping update.")
    
    # Launch GUI
    print("[*] Launching MusicCloud Desktop Player...")
    if os.path.exists(PLAYER_FILE):
        subprocess.Popen([sys.executable, PLAYER_FILE], cwd=LOCAL_DIR)
    else:
        print(f"[!] Cannot launch: {PLAYER_FILE} not found!")

if __name__ == "__main__":
    main()
